package com.example.libraryapp.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.libraryapp.model.Anime
import com.example.libraryapp.database.dao.AnimeDao
import com.example.libraryapp.database.dao.CustomerDao
import com.example.libraryapp.database.dao.RentalDao
import com.example.libraryapp.model.Customer
import com.example.libraryapp.model.Rental

@Database(entities = [Anime::class, Customer::class, Rental::class], version = 2)
@TypeConverters(Converters::class)
abstract class AppDatabase: RoomDatabase() {
    companion object {
        val DATABASE_NAME = "anime"
    }
    abstract fun bookDao(): AnimeDao
    abstract fun customerDao(): CustomerDao
    abstract fun rentalDao(): RentalDao
    abstract fun AnimeDao(): Any
    abstract fun animeDao(): Any


}
