package com.example.libraryapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.room.Room
import com.example.libraryapp.database.AppDatabase
import com.example.libraryapp.databinding.ActivityCreateAnimeBinding
import com.example.libraryapp.model.Anime

class CreateAnimeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCreateAnimeBinding

    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateAnimeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = Room
            .databaseBuilder(
                this,
                AppDatabase::class.java,
                AppDatabase.DATABASE_NAME
            )
            .allowMainThreadQueries().build()

        binding.saveButton.setOnClickListener{
            val titulo = binding.tituloEditText.text.toString()
            val fecha = binding.fechaEditText.text.toString()
            val descripcion = binding.descripcionEditText.text.toString()
            val autor = binding.autorEditText.text.toString()

            val anime = Anime(
                titulo = titulo,
                fecha = fecha,
                descripcion = descripcion,
                autor = autor
            )

            db
                .AnimeDao()
                .save(anime)


            finish()
        }
    }
}

fun Any.save(anime: Anime) {
    TODO("Not yet implemented") }