package com.example.libraryapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Adapter
import com.example.libraryapp.database.AppDatabase
import com.example.libraryapp.databinding.AnimeLayoutBinding
import com.example.libraryapp.model.Anime

class AnimeAdapter(
    var anime: List<Anime>,
    val context: Context,
    val db: AppDatabase
) :

    Adapter<AnimeAdapter.ItemViewHolder>() {

    private val layoutInflater = LayoutInflater.from(context)

    class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            layoutInflater.inflate(R.layout.anime_layout, null)
        )
    }

    override fun getItemCount(): Int {
        return anime.size
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val book = anime[position]
        val binding = AnimeLayoutBinding.bind(holder.itemView)

        binding.tituloTextView.text = book.titulo


        binding.fechaTextView.text = book.fecha

        binding.autorTextView.text = book.descripcion

        binding.descripcionTextView.text = book.autor

        binding.deleteBookButton.setOnClickListener{
            val deletedRows = db.bookDao().delete(book.titulo)

            anime = db.bookDao().list()

            notifyDataSetChanged()
            if(deletedRows == 0) {
                Toast.makeText(context, "No se ha eliminado ningún libro", Toast.LENGTH_LONG).show()
            }
        }
    }


}